import java.time.LocalDate;
import java.time.Period;
import java.util.*;
public class DateDuration {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Date:");
		String str=s.next();
		String st[]=str.split("/");
		LocalDate d=LocalDate.of(Integer.parseInt(st[2]),Integer.parseInt(st[1]),Integer.parseInt(st[0]));
		LocalDate now=LocalDate.now();
		Period p=Period.between(now,d);
		System.out.println("Duration:\nDays "+Math.abs(p.getDays())+"\nMonths:"+Math.abs(p.getMonths())+"\nYears:"+Math.abs(p.getYears()));
	}

}
