import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

public class ProductWarranty {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter product purchase date:");
		String date=s.nextLine();
		String[] dat=date.split("/");
		LocalDate d=LocalDate.of(Integer.parseInt(dat[2]),Integer.parseInt(dat[1]),Integer.parseInt(dat[0]));
		System.out.println("Warranty period in terms of months:");
		int warrPeriod=s.nextInt();
		System.out.println(d.plusMonths(warrPeriod));
		
	}

}
