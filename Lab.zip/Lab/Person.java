import java.time.LocalDate;
import java.util.Date;

public class Person {
	private String name;
	private float age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public float calculateAge(LocalDate d)
	{
		LocalDate date=LocalDate.now();
		return date.getYear()-d.getYear();
		
	}
	public String getFullName(String firstName,String lastName)
	{
		return "Full name of a person is"+firstName+lastName;
	}
	public void setAge(float age) {
		this.age = age;
	}
}
