
public class MainDemoAccounts {

	public static void main(String[] args) {
		Person p2=new Person();
		p2.setName("Kathy");
		p2.setAge(25);
		Account acc=new SavingsAccount();
		acc.setAccHolder(p2);
		acc.setBalance(3000);
		acc.withdraw(1000);
		System.out.println("Balance is:"+acc.getBalance());
		Account acc1=new CurrentAccount();
		acc.setAccHolder(p2);
		acc.setBalance(0);
		acc1.withdraw(2000);
	}

}
