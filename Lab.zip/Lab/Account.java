import java.time.LocalDate;
import java.time.Month;

public class Account {
	private static long Accnum=10000001;
	protected double balance;
	private Person accHolder;
	public Account()
	{
		Accnum++;
	}
	public void deposit(double balance)
	{
		this.balance+=balance;
		
	}
	public void withdraw(double balance)
	{
		if((this.balance-balance)<=500)
			System.out.println("Cannot be withdrawn minimum balance is Rs.500.");
		else
		this.balance-=balance;
	}
	public double getBalance()
	{
		return this.balance;
	}
	public long getAccnum() {
		return Accnum;
	}
		public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String toString()
	{
		return "Account Number is:"+Accnum+"Name of Account Holder is:"+this.accHolder.getName()+"Age of Account Holder:"+this.accHolder.getAge();
	}
	public static void main(String[] args) {
		Account acc1=new Account();
		Person p1=new Person();
		p1.setName("smith");
		p1.setAge(40);
		acc1.setAccHolder(p1);
		acc1.setBalance(2000);
		Person p2=new Person();
		p2.setName("Kathy");
		p2.setAge(25);
		Account acc2=new Account();
		acc2.setAccHolder(p2);
		acc2.setBalance(3000);
		acc1.deposit(2000);
		acc2.withdraw(2000);
		System.out.println("Balance of Smith is:"+acc1.getBalance());
		System.out.println("Balance of Kathy is:"+acc2.getBalance());
		System.out.println(acc1+"\n"+acc2);
		String name=p1.getFullName("Yaswanth","Koganti");
		float age=p1.calculateAge(LocalDate.of(1997, Month.AUGUST, 23));
		System.out.println("Name is:"+name+"Age is:"+age);
		
		
	}
}
