import java.util.*;
public class PositiveString {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String str=s.next();
		int flag=1;
		for(int i=0;i<str.length()-1;i++) {
			if(str.charAt(i+1)>str.charAt(i))
			{
				flag++;
			
			}
		}
		if(flag==str.length())
		{
			System.out.println("positive String");
			
		}
		else
		{
			System.out.println("Negative String");
		}

	}

}
