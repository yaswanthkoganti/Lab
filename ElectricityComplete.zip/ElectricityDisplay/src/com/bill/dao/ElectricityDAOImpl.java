package com.bill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bill.bean.ElectricityBillBean;
import com.bill.bean.ElectricityConsumerBean;
import com.bill.util.DBconnection;

public class ElectricityDAOImpl implements IElectricityDAO {

	@Override
	public ElectricityConsumerBean isValidConsumer(int consumerNumber) {
		ElectricityConsumerBean cons=null;
		try{
			Connection conn=DBconnection.getConnection();
				PreparedStatement preparedstatement=conn.prepareStatement(IQueryMapper.GETCONSUMERDETAILS);
				preparedstatement.setInt(1,consumerNumber);
				ResultSet result=preparedstatement.executeQuery();
				result.next();
				if(result.getString(1)!=null)
				{
				cons=new ElectricityConsumerBean();
				cons.setConsNumber(consumerNumber);
				cons.setConsName(result.getString(1));
				cons.setAddress(result.getString(2));
				return cons;
				}
	}
		catch(SQLException se)
		{
			
		}
		return cons;
	}

	@Override
	public void addBillDetails(ElectricityBillBean bill) {
		try{
			Connection conn=DBconnection.getConnection();
				PreparedStatement preparedstatement=conn.prepareStatement(IQueryMapper.INSERTBILLDETAILS);
				preparedstatement.setInt(1,bill.getConsNumber());
				preparedstatement.setFloat(2,bill.getCurMonMeterRead());
				preparedstatement.setFloat(3,bill.getUnits());
				preparedstatement.setFloat(4,bill.getNetAmount());
				preparedstatement.executeUpdate();
				
			
	}
		catch(SQLException se)
		{
			
		}

		
	}

	@Override
	public List<ElectricityConsumerBean> getDetails() {
		Connection conn=DBconnection.getConnection();
		List<ElectricityConsumerBean> beanList=new ArrayList<ElectricityConsumerBean>();
		try {
			PreparedStatement preparedstatement=conn.prepareStatement(IQueryMapper.GETDETAILS);
			ResultSet result=preparedstatement.executeQuery();
			while(result.next())
			{
				ElectricityConsumerBean consBean=new ElectricityConsumerBean();
				consBean.setConsName(result.getString(2));
				consBean.setConsNumber(result.getInt(1));
				consBean.setAddress(result.getString(3));
				beanList.add(consBean);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return beanList;
	}

	@Override
	public List<ElectricityBillBean> getBillDetails(int consumerNumber) {
		List<ElectricityBillBean> beanList=new ArrayList<ElectricityBillBean>();
		try {
			Connection conn=DBconnection.getConnection();
			PreparedStatement preparedstatement=conn.prepareStatement(IQueryMapper.GETBILLDETAILS);
			preparedstatement.setInt(1,consumerNumber);
			ResultSet result=preparedstatement.executeQuery();
			while(result.next())
			{
				ElectricityBillBean bill=new ElectricityBillBean();
				bill.setBillNumber(result.getInt(1));
				bill.setCurMonMeterRead(result.getFloat(3));
				bill.setBillmonth(result.getString(2));
				bill.setUnits(result.getFloat(4));
				bill.setNetAmount(result.getFloat(5));
				beanList.add(bill);
			}
			
	}
		catch(SQLException e)
		{
			
		}
		return beanList;
}

	@Override
	public ElectricityConsumerBean getCustomer(int consumerNumber) {
		Connection conn=DBconnection.getConnection();
		ElectricityConsumerBean cons=null;
		try{
			PreparedStatement preparedstatement=conn.prepareStatement(IQueryMapper.GETCONSUMERDETAILS);
			preparedstatement.setInt(1,consumerNumber);
			ResultSet result=preparedstatement.executeQuery();
			result.next();
			if(result.getString(1)!=null)
			{
			cons=new ElectricityConsumerBean();
			cons.setConsNumber(consumerNumber);
			cons.setConsName(result.getString(1));
			cons.setAddress(result.getString(2));
			return cons;
			}
			
		}
		catch(SQLException e)
		{
			
		}
		return cons;
	}
}
