package com.ars.dao;

import java.util.List;

import com.ars.bean.FlightInformation;
import com.ars.bean.Users;
import com.ars.exception.AirlineException;

public interface IAirlineDao {

	boolean verifyUser(String uName, String password) throws AirlineException;

	void addUserDetails(Users user) throws AirlineException;

	String getRole(Users user) throws AirlineException;

	List<FlightInformation> getFlightInfo(FlightInformation flight) throws AirlineException;

	void updatePassword(String password) throws AirlineException;

}
