package com.ars.dao;

public interface IQueryMapper {

	public static final String VALIDATEUSER = "Select count(*) from users WHERE username=? AND password=?";
	public static final String INSERTQUERY = "Insert into users values(?,?,?,?)";
	public static final String GETROLE = "Select role from users where username=? AND password=?";
	public static final String GETFLIGHTINFO = "SELECT * from flightinformation where dep_city=? AND arr_city=?";
	public static final String UPDATEPASSWORD = "UPDATE users SET password=?";
	

	

}
