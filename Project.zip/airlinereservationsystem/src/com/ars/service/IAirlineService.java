package com.ars.service;

import java.util.List;

import com.ars.bean.FlightInformation;
import com.ars.bean.Users;
import com.ars.exception.AirlineException;

public interface IAirlineService {

	boolean isValidName(String uName) throws AirlineException;

	boolean isValidPassword(String password);

	boolean isValidEmail(String email) throws AirlineException;

	boolean verifyUser(String uName, String password) throws AirlineException;

	void addUserDetails(Users user) throws AirlineException;
	String getRole(Users user) throws AirlineException;

	List<FlightInformation> getFlightInfo(FlightInformation flightinfo) throws AirlineException;

	void updatePassword(String password) throws AirlineException;
}
