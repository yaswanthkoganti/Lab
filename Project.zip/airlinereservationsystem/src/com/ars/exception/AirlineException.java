package com.ars.exception;

public class AirlineException extends Exception {

	public AirlineException()
	{
		
	}
	public AirlineException(String string) {
	super(string);
	}

}
