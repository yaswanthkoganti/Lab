package com.ars.pi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.ars.bean.BookingInformation;
import com.ars.bean.FlightInformation;
import com.ars.bean.Users;
import com.ars.dao.AirlineDaoImpl;
import com.ars.dao.IAirlineDao;
import com.ars.exception.AirlineException;
import com.ars.service.AirlineServiceImpl;
import com.ars.service.IAirlineService;

public class AirlineMain {

	public static void main(String[] args) {
			int choice,coun=0;
			String uName,password,email,pass;
			IAirlineService is=new AirlineServiceImpl();
			Users user=null;
			try{
			Scanner scan=new Scanner(System.in);
			System.out.println("Choose from below options:");
			System.out.println("1.Register\n2.Login");
			choice=scan.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Please enter the details to complete registration:");
				do{
				System.out.println("UserName:");
				 uName=scan.next();
				}
				while(is.isValidName(uName));
				do{
				System.out.println("Password:");
				password=scan.next();
				}while(is.isValidPassword(password));
				do{
				System.out.println("E-mail:");
				email=scan.next();
				}while(is.isValidEmail(email));
				user=new Users();
				user.setRole("user");
				user.setuName(uName);
				user.setPassword(password);
				user.setEmail(email);
				is.addUserDetails(user);
				break;
			case 2:
				System.out.println("Please enter your login credentials:");
				do{
					user=new Users();
					System.out.println("UserName:");
					uName=scan.next();
					System.out.println("Password:");
					password=scan.next();
					coun++;
					if(coun==3)
					{
						System.out.println("You Need to Reset your password.");
						System.out.println("Enter your email ID");
						email=scan.next();
						System.out.println("Enter new password to login");
						pass=scan.next();
						is.isValidPassword(pass);
						is.updatePassword(email,pass);
						coun=0;
					}	
				}while(is.verifyUser(uName,password));
				user.setuName(uName);
				user.setPassword(password);
				if(is.getRole(user).equals("user"))
					getAirlines(user);			
			}
			}
			catch(AirlineException ae)
			{
				System.out.println("hello");
				System.err.println("Error Occured"+ae.getMessage());
				main(args);
			}
			
	}

	private static void getAirlines(Users user) throws AirlineException {
		Scanner scan=new Scanner(System.in);
		int choice;
		List<FlightInformation> airList=
		System.out.println("Welcome to Capgemini Airlines.");
		System.out.println("Please choose from below options:");
		System.out.println("1)Book Ticket\n2)View Ticket Info\n3)Cancel Booking");
		choice=scan.nextInt();
		switch(choice)
		{
		case 1:
		System.out.println("Please Enter your Source city:");
		String depCity=scan.next();
		System.out.println("Please Enter your destination city:");
		String arrCity=scan.next();
		IAirlineService is=new AirlineServiceImpl();
		FlightInformation flightinfo= new FlightInformation();
		flightinfo.setDepCity(depCity);
		flightinfo.setArrCity(arrCity);
		airList=is.getFlightInfo(flightinfo);
		if (airList != null) {
			Iterator<FlightInformation> i = airList.iterator();
			while (i.hasNext()) {
				System.out.println(i.next());
			}
		}
		System.out.println("Enter flightno to book ticket");
		String flightNum=scan.next();
		System.out.println("Choose the class type from the following:");
		System.out.println("1)Bussiness Class 2)First Class");
		int type=scan.nextInt();
		System.out.println("Enter no of tickets:");
		int noofTickets=scan.nextInt();
		BookingInformation bookInfo=new BookingInformation();
		if(type==1)
			bookInfo.setClassType("Bussiness");
		else
			bookInfo.setClassType("First");;
		bookInfo.setNoOfPassengers(noofTickets);
		is.bookTicket(bookInfo);
		
		}
		
	}

}
