package com.ars.bean;

import java.sql.Date;


public class FlightInformation {
private String flightNo;
private String airline;
private String depCity;
private String arrCity;
private Date depDate;
private Date arrDate;
private String depTime;
private String arrTime;
private String seatType;
public String getSeatType() {
	return seatType;
}
public void setSeatType(String seatType) {
	this.seatType = seatType;
}
public String getArrTime() {
	return arrTime;
}
public void setArrTime(String arrTime) {
	this.arrTime = arrTime;
}
private int firstSeats;
private double firstSeatFare;
private int bussSeats;
private double BussSeatsFare;
public String getFlightNo() {
	return flightNo;
}
public void setFlightNo(String flightNo) {
	this.flightNo = flightNo;
}
public String getAirline() {
	return airline;
}
public void setAirline(String airline) {
	this.airline = airline;
}
public String getDepCity() {
	return depCity;
}
public void setDepCity(String depCity) {
	this.depCity = depCity;
}
public String getArrCity() {
	return arrCity;
}
public void setArrCity(String arrCity) {
	this.arrCity = arrCity;
}
public Date getDepDate() {
	return depDate;
}
public void setDepDate(Date depDate) {
	this.depDate = depDate;
}
public Date getArrDate() {
	return arrDate;
}
public void setArrDate(Date arrDate) {
	this.arrDate = arrDate;
}
public String getDepTime() {
	return depTime;
}
public void setDepTime(String depTime) {
	this.depTime = depTime;
}
public int getFirstSeats() {
	return firstSeats;
}
public void setFirstSeats(int firstSeats) {
	this.firstSeats = firstSeats;
}
public double getFirstSeatFare() {
	return firstSeatFare;
}
public void setFirstSeatFare(double firstSeatFare) {
	this.firstSeatFare = firstSeatFare;
}
public int getBussSeats() {
	return bussSeats;
}
public void setBussSeats(int bussSeats) {
	this.bussSeats = bussSeats;
}
public double getBussSeatsFare() {
	return BussSeatsFare;
}
public void setBussSeatsFare(double bussSeatsFare) {
	BussSeatsFare = bussSeatsFare;
}


}
