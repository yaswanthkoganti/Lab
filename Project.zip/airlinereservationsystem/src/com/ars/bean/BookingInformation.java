package com.ars.bean;

public class BookingInformation {

}
