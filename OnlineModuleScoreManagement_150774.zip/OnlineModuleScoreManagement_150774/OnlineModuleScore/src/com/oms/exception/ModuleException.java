package com.oms.exception;

public class ModuleException extends Exception{
private String msg;
public ModuleException() {
}
public ModuleException(String msg)
{
	this.msg=msg;
}
public String toString()
{
	return this.msg;
}
}
