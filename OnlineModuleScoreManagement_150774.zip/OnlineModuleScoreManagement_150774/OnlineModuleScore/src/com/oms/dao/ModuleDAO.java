package com.oms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.jboss.dmr.stream.ModelException;

import com.oms.bean.TraineeBean;
import com.oms.exception.ModuleException;
import com.oms.util.DBconnection;
public class ModuleDAO implements IModuleDAO {
	/*******************************************************************************************************
	 - Function Name	:	getTraineeList()
	 - Input Parameters	:	
	 - Return Type		:	List<Integer>
	 - Throws			:  	ModuleException
	 - Author			:	yaswanth
	 - Creation Date	:	02/07/2018
	 - Description		:	returns all the traineeId from the table
	 ********************************************************************************************************/
	@Override
	public List<Integer> getTraineeList() throws ModuleException {
		List<Integer> traineeList=null;
		try {
			Connection con=DBconnection.getConnection();
				PreparedStatement preparedStatement=con.prepareStatement(IQuerryMapper.GETTRAINEEID);
				ResultSet result=preparedStatement.executeQuery();
				traineeList=new ArrayList<Integer>();
				while(result.next())
				{
					traineeList.add(result.getInt(1));
				}
				try{
					result.close();
					preparedStatement.close();
					con.close();
				}
				catch(SQLException e)
				{
					throw new ModuleException("DB Closing problem");
				}
				
	}
		catch(SQLException e)
		{
			throw new ModuleException("DBConnection problem");
		}
		return traineeList;
	}
	/*******************************************************************************************************
	 - Function Name	:	addAssessmentScore(TraineeBean bean)
	 - Input Parameters	:	TraineeBean bean
	 - Return Type		:	void
	 - Throws			:  	ModuleException
	 - Author			:	yaswanth
	 - Creation Date	:	02/07/2018
	 - Description		:	add the assessment score into the table
	 ********************************************************************************************************/
	@Override
	public void addAssessmentScore(TraineeBean bean) throws ModuleException {
		try {
			Connection con=DBconnection.getConnection();
				PreparedStatement preparedStatement=con.prepareStatement(IQuerryMapper.ADDASSESSMENTSCORE);
				preparedStatement.setInt(1,bean.getTraineeId());
				preparedStatement.setString(2,bean.getModuleName());
				preparedStatement.setInt(3,bean.getMpt());
				preparedStatement.setInt(4,bean.getMtt());
				preparedStatement.setInt(5,bean.getassignment());
				preparedStatement.setInt(6,bean.getTotalMarks());
				preparedStatement.setInt(7,bean.getGrade());
				preparedStatement.executeUpdate();
				try{
					preparedStatement.close();
					con.close();
				}
				catch(SQLException e)
				{
					throw new ModuleException("DB Closing problem");
				}
				
	}
		catch(SQLException e)
		{
			throw new ModuleException("DB Connection problem");
		}
	}
	/*******************************************************************************************************
	 - Function Name	:	isValid()
	 - Input Parameters	:	int traineeId, String moduleName
	 - Return Type		:	boolean
	 - Throws			:  	ModuleException
	 - Author			:	yaswanth
	 - Creation Date	:	02/07/2018
	 - Description		:	checks whether the trainee has already submitted marks for the  moduleName
	 ********************************************************************************************************/
	@Override
	public boolean isValid(int traineeId, String moduleName) throws ModuleException {
		try {
			Connection con=DBconnection.getConnection();
				PreparedStatement preparedStatement=con.prepareStatement(IQuerryMapper.CHECKASSESSMENTSCORE);
				preparedStatement.setInt(1,traineeId);
				preparedStatement.setString(2,moduleName);
				ResultSet result=preparedStatement.executeQuery();
				result.next();
				if(result.getInt(1)>=1)
				{
					return false;
				}
				try{
					result.close();
					preparedStatement.close();
					con.close();
				}
				catch(SQLException e)
				{
					throw new ModuleException("DB Closing problem");
				}
		}
		catch(SQLException e)
		{
			throw new ModuleException("DB Connection problem");
		}
		
		return true;
	}
	
}
