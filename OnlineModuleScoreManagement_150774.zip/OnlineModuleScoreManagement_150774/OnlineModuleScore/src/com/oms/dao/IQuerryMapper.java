package com.oms.dao;

public interface IQuerryMapper {

	public static final String GETTRAINEEID ="SELECT trainee_id FROM trainees";
	public static final String ADDASSESSMENTSCORE = "INSERT INTO AssessmentScore values(?,?,?,?,?,?,?)";
	public static final String CHECKASSESSMENTSCORE = "SELECT COUNT(*) FROM AssessmentScore where trainee_id=? AND module_name=?";

}
