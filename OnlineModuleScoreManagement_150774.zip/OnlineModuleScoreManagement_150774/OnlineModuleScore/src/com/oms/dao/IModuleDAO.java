package com.oms.dao;

import java.util.List;

import org.jboss.dmr.stream.ModelException;

import com.oms.bean.TraineeBean;
import com.oms.exception.ModuleException;

public interface IModuleDAO {

	List<Integer> getTraineeList() throws ModuleException;

	void addAssessmentScore(TraineeBean bean) throws ModuleException;

	boolean isValid(int traineeId, String moduleName) throws ModuleException;

}
