package com.oms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oms.bean.TraineeBean;
import com.oms.exception.ModuleException;
import com.oms.service.IModuleService;
import com.oms.service.ModuleService;

/**
 * Servlet implementation class ModuleController
 */
@WebServlet("/ModuleController")
public class ModuleController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModuleController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String option=request.getParameter("action");//get the action parameter
		IModuleService modServ=new ModuleService();//create object of ModuleService by using IModuleService interface reference
		try{
			switch(option)//checking the option value
			{
			case "addAssessmentDetails":
				List<Integer> traineeIdList=modServ.getTraineeList();//get the traineeId list by calling service method
				request.setAttribute("traineeId",traineeIdList);//setting traineeId attribute using request object
				getServletContext().getRequestDispatcher("/AddAssessment.jsp").forward(request,response);//redirecting to AddAssessment.jsp using requestdispatcher
				break;
			case "Submit":
				int traineeId=Integer.parseInt(request.getParameter("traineeId"));
				String moduleName=request.getParameter("moduleName");
				if(modServ.isValid(traineeId,moduleName))//verifying whether user has already submitted the module score
				{
					int mpt=Integer.parseInt(request.getParameter("mpt"));
					int mtt=Integer.parseInt(request.getParameter("mtt"));
					int assignment=Integer.parseInt(request.getParameter("assignment"));
					int total=(int) (Math.round((mpt*0.7)+(mtt*0.15)+(assignment*0.15)));//calculating total
					TraineeBean bean=new TraineeBean();//setting the values in TraineeBean 
					bean.setTraineeId(traineeId);
					bean.setModuleName(moduleName);
					bean.setMpt(mpt);
					bean.setMtt(mtt);
					bean.setassignment(assignment);
					bean.setTotalMarks(total);
					if(total>=90&&total<=100)//setting grade based on total
						bean.setGrade(5);
					else if(total>=80&&total<=89)
						bean.setGrade(4);
					else if(total>=70&&total<=79)
						bean.setGrade(3);
					else if(total>=60&&total<=69)
						bean.setGrade(2);
					else if(total>=50&&total<=59)
						bean.setGrade(1);
					else
						bean.setGrade(0);
					modServ.addAssessmentScore(bean);//adding the details into database by calling addAssessmentScore method of service
					request.setAttribute("ModuleBean",bean);//setting  the attribute using request object 
					getServletContext().getRequestDispatcher("/ModuleScore.jsp").forward(request,response);//redirecting to ModuleScore.jsp using requestdispatcher
				}
				else
				{
					throw new ModuleException("Assessment Score already Submitted");//if score already submitted raising exception
				}
			}
		}
	catch(ModuleException e)//catch block to handle all the exception
		{
		request.setAttribute("error",e);
		List<Integer> traineeIdList=null;
		try {
			traineeIdList = modServ.getTraineeList();//again set the drop down list with values when redirected to same page when error occured
		} catch (ModuleException e1) {
			System.out.println(e1);
		}
		request.setAttribute("traineeId",traineeIdList);
		getServletContext().getRequestDispatcher("/AddAssessment.jsp").forward(request,response);//redirecting again to AddAssessment.jsp with error message
		}
    }
		
}
