package com.oms.service;

import java.util.List;

import com.oms.bean.TraineeBean;
import com.oms.exception.ModuleException;

public interface IModuleService {

	List<Integer> getTraineeList() throws ModuleException;

	void addAssessmentScore(TraineeBean bean) throws ModuleException;

	boolean isValid(int traineeId, String moduleName) throws ModuleException;


}
