package com.oms.service;

import java.util.List;

import com.oms.bean.TraineeBean;
import com.oms.dao.IModuleDAO;
import com.oms.dao.ModuleDAO;
import com.oms.exception.ModuleException;

public class ModuleService implements IModuleService{
	/*******************************************************************************************************
	 - Function Name	:	getTraineeList()
	 - Input Parameters	:	
	 - Return Type		:	List<Integer>
	 - Throws			:  	ModuleException
	 - Author			:	yaswanth
	 - Creation Date	:	02/07/2018
	 - Description		:	returns all the traineeId from the table by calling getTraineeList dao method 
	 ********************************************************************************************************/
	@Override
	public List<Integer> getTraineeList() throws ModuleException {
		IModuleDAO module=new ModuleDAO();
		return module.getTraineeList();
	}
	/*******************************************************************************************************
	 - Function Name	:	addAssessmentScore(TraineeBean bean)
	 - Input Parameters	:	TraineeBean bean
	 - Return Type		:	void
	 - Throws			:  	ModuleException
	 - Author			:	yaswanth
	 - Creation Date	:	02/07/2018
	 - Description		:	add the assessment score into the table by calling addAssessmentScore dao method
	 ********************************************************************************************************/
	@Override
	public void addAssessmentScore(TraineeBean bean) throws ModuleException {
		IModuleDAO module=new ModuleDAO();
		module.addAssessmentScore(bean);
		
	}
	/*******************************************************************************************************
	 - Function Name	:	isValid()
	 - Input Parameters	:	int traineeId, String moduleName
	 - Return Type		:	boolean
	 - Throws			:  	ModuleException
	 - Author			:	yaswanth
	 - Creation Date	:	02/07/2018
	 - Description		:	checks whether the trainee has already submitted marks for the moduleName by calling isValid method in dao
	 ********************************************************************************************************/
	@Override
	public boolean isValid(int traineeId, String moduleName) throws ModuleException {
		IModuleDAO module=new ModuleDAO();
		return module.isValid(traineeId,moduleName);
	}

}
