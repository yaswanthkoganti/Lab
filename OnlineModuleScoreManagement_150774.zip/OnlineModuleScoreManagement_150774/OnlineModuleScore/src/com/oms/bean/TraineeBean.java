package com.oms.bean;

public class TraineeBean {
private int traineeId;
private String moduleName;
private int mpt;
private int mtt;
private int assignment;
private int totalMarks;
private int grade;
public int getTraineeId() {
	return traineeId;
}
public void setTraineeId(int traineeId) {
	this.traineeId = traineeId;
}
public String getModuleName() {
	return moduleName;
}
public void setModuleName(String moduleName) {
	this.moduleName = moduleName;
}
public int getMpt() {
	return mpt;
}
public void setMpt(int mpt) {
	this.mpt = mpt;
}
public int getMtt() {
	return mtt;
}
public void setMtt(int mtt) {
	this.mtt = mtt;
}
public int getassignment() {
	return assignment;
}
public void setassignment(int assignment) {
	this.assignment = assignment;
}
public int getTotalMarks() {
	return totalMarks;
}
public void setTotalMarks(int totalMarks) {
	this.totalMarks = totalMarks;
}
public int getGrade() {
	return grade;
}
public void setGrade(int grade) {
	this.grade = grade;
}

}
