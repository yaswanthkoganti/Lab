package com.oms.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.oms.exception.ModuleException;

public class DBconnection {
	/*******************************************************************************************************
	 - Function Name	:	getConnection()
	 - Input Parameters	:	
	 - Return Type		:	Connection
	 - Throws			: 	ModuleException 
	 - Author			:	yaswanth
	 - Creation Date	:	02/07/2018
	 - Description		:	returns Connection object using datasource
	 ********************************************************************************************************/
	public static Connection getConnection() throws ModuleException{
	Connection conn=null;
		try {
			InitialContext ic=new InitialContext();
			DataSource ds=(DataSource) ic.lookup("java:/OracleDS");
		conn=ds.getConnection();
	} catch (SQLException|NamingException e) {
		throw new ModuleException("DB connection object creation problem");
	} 
		return conn;
		
	}
}
