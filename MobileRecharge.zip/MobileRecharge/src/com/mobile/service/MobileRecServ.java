package com.mobile.service;

import com.mobile.bean.MobileBean;
import com.mobile.dao.IMobileDao;
import com.mobile.dao.MobileDaoImpl;

public class MobileRecServ implements IMobileRech{

	@Override
	public int getBillId() {
		IMobileDao mobile=new MobileDaoImpl();
		return mobile.getMobileId();
	}

	@Override
	public void addBill(MobileBean mobile) {
		IMobileDao mobileda=new MobileDaoImpl();
		mobileda.addBill(mobile);
		
	}

}
