package com.mobile.service;

import com.mobile.bean.MobileBean;

public interface IMobileRech {

	int getBillId();

	void addBill(MobileBean mobile);

}
