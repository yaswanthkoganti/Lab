package com.mobile.bean;

public class MobileBean {
private String mobileNum;
private String billNum;
private String rechDate;
private String rechPlan;
private double amount;
public String getMobileNum() {
	return mobileNum;
}
public void setMobileNum(String mobileNum) {
	this.mobileNum = mobileNum;
}
public String getBillNum() {
	return billNum;
}
public void setBillNum(String billNum) {
	this.billNum = billNum;
}
public String getRechDate() {
	return rechDate;
}
public void setRechDate(String rechDate) {
	this.rechDate = rechDate;
}
public String getRechPlan() {
	return rechPlan;
}
public void setRechPlan(String rechPlan) {
	this.rechPlan = rechPlan;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}


}
