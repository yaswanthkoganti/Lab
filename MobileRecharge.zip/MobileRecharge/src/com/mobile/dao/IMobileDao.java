package com.mobile.dao;

import com.mobile.bean.MobileBean;

public interface IMobileDao {

	int getMobileId();

	void addBill(MobileBean mobile);

}
