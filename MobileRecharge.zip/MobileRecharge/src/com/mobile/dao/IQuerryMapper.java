package com.mobile.dao;

public interface IQuerryMapper {

	String GETSEQID = "SELECT BILL_SEQ.NEXTVAL FROM DUAL";
	String ADDBILL = "INSERT INTO bill values(?,?,?,?,?)";

}
