package com.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mobile.bean.MobileBean;
import com.mobile.util.DBconnection;

public class MobileDaoImpl implements IMobileDao {

	@Override
	public int getMobileId() {
		int billId=0;
		try {
		Connection con=DBconnection.getConnection();
			PreparedStatement preparedStatement=con.prepareStatement(IQuerryMapper.GETSEQID);
			ResultSet result=preparedStatement.executeQuery();
			result.next();
			billId=result.getInt(1); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return billId;
	}

	@Override
	public void addBill(MobileBean mobile) {
		try {
			Connection con=DBconnection.getConnection();
				PreparedStatement preparedStatement=con.prepareStatement(IQuerryMapper.ADDBILL);
				preparedStatement.setString(1,mobile.getBillNum());
				preparedStatement.setString(2,mobile.getMobileNum());
				preparedStatement.setString(3,mobile.getRechDate());
				preparedStatement.setString(4,mobile.getRechPlan());
				preparedStatement.setDouble(5,mobile.getAmount());
			preparedStatement.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

}
