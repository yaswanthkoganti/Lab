package com.bill.dto;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bill.bean.ElectricityBillBean;
import com.bill.bean.ElectricityConsumerBean;
import com.bill.service.ElectricityBillServImpl;
import com.bill.service.IElectricityBillService;
import com.sun.org.apache.bcel.internal.generic.LSTORE;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String option=request.getParameter("action");
		if(option.equals("login"))
		{
			if(request.getParameter("uName").equals("admin")&&request.getParameter("pass").equals("admin"))
			{
				getServletContext().getRequestDispatcher("/Bill.html").forward(request,response);
			}
		}
		else if(option.equals("Calculate Bill"))
		{
		int consumerNumber=Integer.parseInt(request.getParameter("cNumber"));
		float lastMonMeterRead=Float.parseFloat(request.getParameter("lastMonReading"));
		float currentMonMeterRead=Float.parseFloat(request.getParameter("currentMonReading"));
		final float FIXEDCHARGES=100f; 
		float units,netAmount=0;
		IElectricityBillService ibill=new ElectricityBillServImpl();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		ElectricityConsumerBean cons=ibill.isValidConsumerNum(consumerNumber);
		if(cons!=null)
		{	
			if(currentMonMeterRead<lastMonMeterRead)
				out.println("Invalid Meter Reading");
			else
				{
					units=(currentMonMeterRead-lastMonMeterRead);
					netAmount=(float) (units*1.15+FIXEDCHARGES);
					ElectricityBillBean bill=new ElectricityBillBean();
					bill.setConsNumber(cons.getConsNumber());
					bill.setCurMonMeterRead(currentMonMeterRead);
					bill.setNetAmount(netAmount);
					bill.setUnits(units);
					ibill.addBillDetails(bill);
					/*request.setAttribute("bill",bill);
					request.setAttribute("consumer",cons);*/
					out.println("Welcome "+cons.getConsName());
					out.println("<br/><h2>Electricity Bill For Consumer Number - "+bill.getConsNumber()+"is<br/>");
					out.print("Units Consumed:: "+bill.getUnits());
					out.print("Net Amount::Rs. "+bill.getNetAmount());
				}
		}
		else{
			out.println("Invalid Consumer Number");
		}
	}
}
}