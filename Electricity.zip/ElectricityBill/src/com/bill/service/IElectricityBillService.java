package com.bill.service;

import com.bill.bean.ElectricityBillBean;
import com.bill.bean.ElectricityConsumerBean;

public interface IElectricityBillService {

	void addBillDetails(ElectricityBillBean bill);

	ElectricityConsumerBean isValidConsumerNum(int consumerNumber);

}
