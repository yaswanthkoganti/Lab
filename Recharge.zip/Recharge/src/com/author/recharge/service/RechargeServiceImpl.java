package com.author.recharge.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.dao.IRechargeDao;
import com.author.recharge.dao.RechargeDaoImpl;
import com.author.recharge.exception.InvalidRecharge;

public class RechargeServiceImpl implements IRechargeService{
private static String status;
@Override
	public StringBuilder displayPlans() throws InvalidRecharge {
		IRechargeDao i=new RechargeDaoImpl();
		return i.displayPlans();
	}

	@Override
	public void addUserDetails(RechargeBean rb) throws InvalidRecharge {
		// TODO Auto-generated method stub
		IRechargeDao r=new RechargeDaoImpl();
		r.addUserDetails(rb);
	
	}

	@Override
	public boolean retrieveUserDetails(String rechId,RechargeBean  b1) throws InvalidRecharge {
		IRechargeDao r=new RechargeDaoImpl();
		return r.retrieveUserDetails(rechId,b1);
		
	}
	@Override
	public int retrieveAmount(String plan) throws InvalidRecharge {
		IRechargeDao i=new RechargeDaoImpl();
		return i.retrieveAmount(plan);
	}
	public boolean isValidMobile(String mobileNum)
	{
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(mobileNum);
		return m.matches();
	}

	@Override
	public boolean isValidName(String name) {
		Pattern p=Pattern.compile("[A-Z a-z]{3,}");
		Matcher m=p.matcher(name);
		return m.matches();
	}

	@Override
	public boolean isValidRecharge(RechargeBean b1) {
		if(b1.getStatus().equals("Success"))
			return true;
		else
		return false;
	}

}
