package com.author.recharge.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.dao.IRechargeDao;
import com.author.recharge.dao.RechargeDaoImpl;
import com.author.recharge.exception.InvalidRecharge;

public class RechargeServiceImpl implements IRechargeService{
private static String status;
/*******************************************************************************************************
- Function Name	:	displayPlans()
- Input Parameters	:	
- Return Type		:	StringBuilder
- Throws			:  InvalidRecharge
- Author			:	CAPGEMINI
- Creation Date  	:	18/06/2018
- Description		:	get plan details from database by calling displayPlans() method in dao method
********************************************************************************************************/
@Override
	public StringBuilder displayPlans() throws InvalidRecharge {
		IRechargeDao i=new RechargeDaoImpl();
		return i.displayPlans();
	}
/*******************************************************************************************************
- Function Name	:	addUserDetails(RechargeBean b1)
- Input Parameters	:	RechargeBean b1
- Return Type		:	void
- Throws			:  	InvalidRecharge
- Author			:	CAPGEMINI
- Creation Date	:	18/06/2018
- Description		:	add user to database by calling addUserDetails() method in dao
********************************************************************************************************/
	@Override
	public void addUserDetails(RechargeBean rb) throws InvalidRecharge {
		IRechargeDao r=new RechargeDaoImpl();
		r.addUserDetails(rb);
	
	}
	/*******************************************************************************************************
	- Function Name	    :	retrieveUserDetails(RechargeBean b1)
	- Input Parameters	:	String rechId,RechargeBean b1
	- Return Type		:	boolean
	- Throws			:  	InvalidRecharge
	- Author			:	CAPGEMINI
	- Creation Date	    :	18/06/2018
	- Description		:	retrieve user details from  database by calling retrieveUserDetails() method in dao
	********************************************************************************************************/
	@Override
	public boolean retrieveUserDetails(String rechId,RechargeBean  b1) throws InvalidRecharge {
		IRechargeDao r=new RechargeDaoImpl();
		return r.retrieveUserDetails(rechId,b1);
		
	}
	/*******************************************************************************************************
	- Function Name 	:	retrieveAmount(String planName)
	- Input Parameters	:	String planName
	- Return Type		:	int
	- Throws			:  	InvalidRecharge
	- Author			:	CAPGEMINI
	- Creation Date	    :	18/06/2018
	- Description		:	retrieve amount from database by calling retrieveAmount() method in dao
	********************************************************************************************************/
	@Override
	public int retrieveAmount(String planName) throws InvalidRecharge {
		IRechargeDao i=new RechargeDaoImpl();
		return i.retrieveAmount(planName);
	}
	/*******************************************************************************************************
	- Function Name 	:	isValidMobile(String mobileNum)
	- Input Parameters	:	String mobileNum
	- Return Type		:	boolean
	- Throws			:   
	- Author			:	CAPGEMINI
	- Creation Date	    :	18/06/2018
	- Description		:	Validate mobile number
	********************************************************************************************************/
	@Override
	public boolean isValidMobile(String mobileNum)
	{
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(mobileNum);
		return m.matches();
	}
	/*******************************************************************************************************
	- Function Name 	:	isValidName(String name)
	- Input Parameters	:	String name
	- Return Type		:	boolean
	- Throws			:   
	- Author			:	CAPGEMINI
	- Creation Date	    :	18/06/2018
	- Description		:	Validate name
	********************************************************************************************************/
	@Override
	public boolean isValidName(String name) {
		Pattern p=Pattern.compile("[A-Z][a-z]{2,}");
		Matcher m=p.matcher(name);
		return m.matches();
	}
	/*******************************************************************************************************
	- Function Name 	:	isValidRecharge(RechargeBean b1)
	- Input Parameters	:	RechargeBean b1
	- Return Type		:	boolean
	- Throws			:   
	- Author			:	CAPGEMINI
	- Creation Date	    :	18/06/2018
	- Description		:	Check recharge successful or failed
	********************************************************************************************************/
	@Override
	public boolean isValidRecharge(RechargeBean b1) {
		if(b1.getStatus().equals("Success"))
			return true;
		else
		return false;
	}

}
