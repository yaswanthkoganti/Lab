package com.author.recharge.dao;


import com.author.recharge.bean.RechargeBean;
import com.author.recharge.exception.InvalidRecharge;

public interface IRechargeDao {
	StringBuilder displayPlans() throws InvalidRecharge;
	void addUserDetails(RechargeBean b1) throws InvalidRecharge;
	boolean retrieveUserDetails(String rechId,RechargeBean b1) throws InvalidRecharge;
	int retrieveAmount(String plan) throws InvalidRecharge;
}
