package com.author.recharge.dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.exception.InvalidRechId;
import com.author.recharge.exception.InvalidRecharge;
import com.author.recharge.service.IRechargeService;
import com.author.recharge.service.RechargeServiceImpl;
import com.author.recharge.util.DBConnection;


public class RechargeDaoImpl implements IRechargeDao{
private static boolean created=true;

Logger logger=Logger.getRootLogger();
public RechargeDaoImpl()
{
PropertyConfigurator.configure("resources//log4j.properties");

}
/*******************************************************************************************************
- Function Name	:	displayPlans()
- Input Parameters	:	
- Return Type		:	StringBuilder
- Throws			:  InvalidRecharge
- Author			:	CAPGEMINI
- Creation Date  	:	18/06/2018
- Description		:	Retrieve plans from database and returns them
********************************************************************************************************/
	@Override
	public StringBuilder displayPlans() throws InvalidRecharge {
		try {
			Connection conn = DBConnection.getInstance().getConnection();
		PreparedStatement pst=conn.prepareStatement(IQueryMapper.VIEWPLANS);
		ResultSet r=pst.executeQuery();
		StringBuilder s2=new StringBuilder("");
		s2.append("plans      amount\n");
		while(r.next())
		{
			s2.append(r.getString(1)+"      "+r.getInt(2)+"\n");
		}		
		return s2;
		}
		catch(SQLException e)
		{
			logger.error(e.getMessage());
			throw new InvalidRecharge("Tehnical problem occured refer log");	
		}

	}
	/*******************************************************************************************************
	 - Function Name	:	addUserDetails(RechargeBean b1)
	 - Input Parameters	:	RechargeBean b1
	 - Return Type		:	void
	 - Throws			:  	InvalidRecharge
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/06/2018
	 - Description		:	Performing Recharge and adding user details to database
	 ********************************************************************************************************/

	@Override
	public void addUserDetails(RechargeBean b1) throws InvalidRecharge {
		try {
			Connection conn = DBConnection.getInstance().getConnection();
			
		java.sql.Statement ss=conn.createStatement();
		ResultSet rs=ss.executeQuery(IQueryMapper.CHECKTABLE);
		rs.next();
		String sr=rs.getString(1);
		if(Integer.parseInt(sr)<=0)
			creation();
		java.sql.Statement ss1=conn.createStatement();
		ResultSet rst=ss1.executeQuery(IQueryMapper.GENERTESEQUENCE);
		rst.next();
		String str=rst.getString(1);
		PreparedStatement pst=conn.prepareStatement(IQueryMapper.GETPLANNAME);
		pst.setString(1,b1.getPlanName());
		ResultSet rs1=pst.executeQuery();
		rs1.next();
		int count=Integer.parseInt(rs1.getString(1));
		if(count<=0)
			b1.setStatus("Failed");
		else
			b1.setStatus("Success");
		PreparedStatement s=conn.prepareStatement(IQueryMapper.INSERTQUERY);
		b1.setRechId(str);
		s.setString(1,b1.getRechId());
		s.setString(2,b1.getUserName());
		s.setString(3,b1.getUserMobileNum());
		s.setString(4,b1.getStatus());
		s.setString(5,b1.getPlanName());
		s.setInt(6,b1.getAmount());
		s.executeUpdate();
		s.close();
		pst.close();
		ss.close();
		rst.close();
		conn.close();
		}
		catch(SQLException e)
		{
			logger.error(e.getMessage());
			throw new InvalidRecharge("Error in closing db connection");		
		}
		
	}
	/*******************************************************************************************************
	 - Function Name	:	retrieveUserDetailsUserDetails(String rechId,RechargeBean bean)
	 - Input Parameters	:	String rechId,RechargeBean b1
	 - Return Type		:	boolean
	 - Throws			:  	InvalidRecharge
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/06/2018
	 - Description		:	retrieve user details from database
	 ********************************************************************************************************/
	@Override
	public boolean retrieveUserDetails(String rechId,RechargeBean bean) throws InvalidRecharge{
		try {
			Connection con = DBConnection.getInstance().getConnection();
		PreparedStatement pst=con.prepareStatement(IQueryMapper.CHECKRECHID);
		pst.setString(1,rechId);
		ResultSet rs1=pst.executeQuery();
		rs1.next();
		int count=Integer.parseInt(rs1.getString(1));
		if(count<=0)
		{
			throw new InvalidRechId();
		}
		else
		{
			PreparedStatement ps=con.prepareStatement(IQueryMapper.GETDETAILS);
			ps.setString(1,rechId);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
		
				bean.setRechId(rechId);
				bean.setUserName(rs.getString(2));
				bean.setUserMobileNum(rs.getString(3));
				bean.setStatus(rs.getString(4));
				bean.setPlanName(rs.getString(5));
				bean.setAmount(rs.getInt(6));
			}
			ps.close();
			rs.close();
			con.close();
			return false;
		}
		}
		catch(InvalidRechId r)
		{
			logger.error("Invalid RechargeId");
			System.out.println(r);
			return true;
		}
		catch (SQLException e) 
		{
			logger.error(e.getMessage());
			throw new InvalidRecharge("Error in closing db connection");

		}
	}
	/*******************************************************************************************************
	 - Function Name	:	retrieveAmount(String planName)
	 - Input Parameters	:	String planName
	 - Return Type		:	int
	 - Throws			:  	InvalidRecharge
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/06/2018
	 - Description		:	retrieve amount for given plan name
	 ********************************************************************************************************/
	@Override
	public int retrieveAmount(String planName) throws InvalidRecharge {
		try {
			Connection conn = DBConnection.getInstance().getConnection();
			PreparedStatement ps=conn.prepareStatement(IQueryMapper.GETDETAILS);
			ps.setString(1,planName);
		int amount=0;
		ResultSet r=ps.executeQuery();
		while(r.next())
		{
			amount=r.getInt(1);
		}
		return amount;
		}catch (SQLException e) 
		{
			logger.error(e.getMessage());
			throw new InvalidRecharge("Error in closing db connection");

		}
		
	}
	/*******************************************************************************************************
	 - Function Name	:	creation()
	 - Input Parameters	:	
	 - Return Type		:	void
	 - Throws			:  	InvalidRecharge
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/06/2018
	 - Description		:	create rechargeinfo table and rech_Id sequence 
	 ********************************************************************************************************/
	public void creation() throws InvalidRecharge
	{
		try {
		Connection conn = DBConnection.getInstance().getConnection();		
		PreparedStatement s=conn.prepareStatement(IQueryMapper.CREATETABLE);
		s.executeUpdate();
		PreparedStatement sn=conn.prepareStatement(IQueryMapper.SEQUENCECREATION);
		sn.executeUpdate();
	}
		catch (SQLException e) 
		{
			logger.error(e.getMessage());
			throw new InvalidRecharge("Error in closing db connection");

		}
	
}
}
