package com.author.recharge.exception;

public class InvalidRechId extends Exception{
private String msg;
	public InvalidRechId()
{
	
}
	public InvalidRechId(String msg) {
		this.msg = msg;
	}
	public String toString()
	{
		return this.msg;
	}
}
