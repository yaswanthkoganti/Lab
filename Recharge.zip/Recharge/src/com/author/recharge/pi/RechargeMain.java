package com.author.recharge.pi;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.author.recharge.bean.RechargeBean;
import com.author.recharge.exception.InvalidRecharge;
import com.author.recharge.service.IRechargeService;
import com.author.recharge.service.RechargeServiceImpl;

public class RechargeMain {
	static Logger logger = Logger.getRootLogger();
	public static void main(String a[]) throws SQLException
	{	try {
		boolean retry=false;
		String mobileNum,name;
	IRechargeService s1=new RechargeServiceImpl();
	System.out.println("Choose plan from below :");
	System.out.println(s1.displayPlans());
		RechargeBean b1=new RechargeBean();
		Scanner sc=new Scanner(System.in);
		do{
		System.out.println("enter username :");
		name=sc.next();
		}while(!s1.isValidName(name));
		b1.setUserName(name);
		do{
		System.out.println("enter mobile number :");
		mobileNum=sc.next();
		}while(!s1.isValidMobile(mobileNum));
		System.out.println("enter Plan Name :");
		String planName=sc.next();
		b1.setUserMobileNum(mobileNum);
		b1.setPlanName(planName);
		s1.retrieveAmount(planName);
		b1.setAmount(s1.retrieveAmount(planName));
		s1.addUserDetails(b1);
		System.out.println(b1.getStatus());
		if(s1.isValidRecharge(b1))
		{
			System.out.println("your mobile has been recharged...rech id is <"+b1.getRechId()+">");
			logger.info("Recharge Successful");
		}
		else
		{
			System.out.println("Your rech id is <"+b1.getRechId()+"> Check your status");
			logger.warn("Recharge Failed due to invalid plan name");
		}
		do{
		System.out.println("Enter your recharge Id :");
		String rech=sc.next();
		retry=s1.retrieveUserDetails(rech,b1);
		System.out.println(b1);
		}while(retry);
	}
	catch(InputMismatchException e)
	{
		logger.error("Exception Occured"+e);
		System.out.println(e);
	}
	catch(ClassCastException ce)
	{
		logger.error("Exception Occured"+ce);
		System.out.println(ce);
	}
	catch(NullPointerException npe)
	{
		logger.error("Exception Occured"+npe);
		System.out.println(npe);
	}
	catch(InvalidRecharge ir)
	{
		logger.error("Exception Occured"+ir);
		System.out.println(ir);
	}
	}
}
