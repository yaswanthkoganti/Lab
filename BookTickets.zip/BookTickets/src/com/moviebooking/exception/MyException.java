package com.moviebooking.exception;

public class MyException extends Exception{
private String msg;
public MyException() {
	// TODO Auto-generated constructor stub
}
public MyException(String msg)
{
	this.msg=msg;
}
public String toString()
{
	return this.msg;
}
}
