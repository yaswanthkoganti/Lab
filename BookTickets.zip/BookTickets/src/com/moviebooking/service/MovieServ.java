package com.moviebooking.service;

import java.util.List;

import com.moviebooking.bean.Moviebooking;
import com.moviebooking.dao.IMovieDao;
import com.moviebooking.dao.MovieDao;
import com.moviebooking.exception.MyException;

public class MovieServ implements IMovieServ {

	@Override
	public List<Moviebooking> getTheatres(Moviebooking movie) throws MyException {
		IMovieDao movieDao=new MovieDao();
		return movieDao.getTheatres(movie);
		
	}

	@Override
	public boolean isValidCity(String city) throws MyException {
		IMovieDao movieDao=new MovieDao();
		return movieDao.isValidCity(city);
	}

	@Override
	public boolean isValidName(String movieName) throws MyException {
		IMovieDao movieDao=new MovieDao();
		return movieDao.isValidName(movieName);
	}

	@Override
	public void updateStatus(String theatreId) throws MyException {
		IMovieDao movieDao=new MovieDao();
		movieDao.updateStatus(theatreId);
		
	}

}
