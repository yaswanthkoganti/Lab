package com.moviebooking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.moviebooking.bean.Moviebooking;
import com.moviebooking.exception.MyException;
import com.moviebooking.util.DBconnection;

public class MovieDao implements IMovieDao{

	@Override
	public List<Moviebooking> getTheatres(Moviebooking movie) throws MyException {
		Connection con=DBconnection.getConnection();
		List<Moviebooking> movieList=null;
		try {
			PreparedStatement preparedStatement=con.prepareStatement(IQueryMapper.getTheatres);
			preparedStatement.setString(1,movie.getCity());
			preparedStatement.setString(2,movie.getMovieName());
			ResultSet result =preparedStatement.executeQuery();
			movieList=new ArrayList<Moviebooking>();
			while(result.next())
			{
				Moviebooking movies=new Moviebooking();
				movies.setMovieId(result.getString(1));
				movies.setMovieName(result.getString(2));
				movies.setTheatreId(result.getString(3));
				movies.setTheatreName(result.getString(4));
				movies.setShowTime(result.getString(5));
				movies.setCity(result.getString(6));
				movies.setLocation(result.getString(7));
				movies.setStatus(result.getString(8));
				movieList.add(movies);
			}
		} catch (SQLException e) {
			throw new MyException("DB Connection problem");
		}
		return movieList;
	}

	@Override
	public boolean isValidCity(String city) throws MyException {
		Connection con=DBconnection.getConnection();
		try {
			PreparedStatement preparedStatement=con.prepareStatement(IQueryMapper.CHECKCITY);
			preparedStatement.setString(1,city);
			ResultSet result=preparedStatement.executeQuery();
			result.next();
			if(result.getInt(1)>=1)
				return true;
		} catch (SQLException e) {
			throw new MyException("DB Connection problem");
		}
		return false;
	}

	@Override
	public boolean isValidName(String name) throws MyException {
		Connection con=DBconnection.getConnection();
		try {
			PreparedStatement preparedStatement=con.prepareStatement(IQueryMapper.CHECKMOVIENAME);
			preparedStatement.setString(1,name);
			ResultSet result=preparedStatement.executeQuery();
			result.next();
			if(result.getInt(1)>=1)
				return true;
		} catch (SQLException e) {
			throw new MyException("DB Connection problem");
		}
		return false;
	}

	@Override
	public void updateStatus(String theatreId) throws MyException {
		Connection con=DBconnection.getConnection();
		try {
			PreparedStatement preparedStatement=con.prepareStatement(IQueryMapper.UPDATESTATUS);
			preparedStatement.setString(1,theatreId);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new MyException("DB Connection problem");
		}
		
	}

}
