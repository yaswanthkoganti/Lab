package com.moviebooking.dao;

public interface IQueryMapper {

	String getTheatres = "SELECT * FROM movies where location=? AND moviename=? AND status='AVAILABLE'";
	String CHECKCITY = "SELECT count(*) FROM movies where location=?";
	String CHECKMOVIENAME = "SELECT count(*) FROM movies where moviename=?";
	String UPDATESTATUS = "UPDATE movies SET status='UNAVAILABLE' where theatreid=?";

}
