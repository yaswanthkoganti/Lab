package com.moviebooking.dao;

import java.util.List;

import com.moviebooking.bean.Moviebooking;
import com.moviebooking.exception.MyException;

public interface IMovieDao {

	List<Moviebooking> getTheatres(Moviebooking movie) throws MyException;

	boolean isValidCity(String city) throws MyException;

	boolean isValidName(String movieName) throws MyException;

	void updateStatus(String theatreId) throws MyException;

}
