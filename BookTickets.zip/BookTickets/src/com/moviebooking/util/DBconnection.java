package com.moviebooking.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBconnection {
public static Connection getConnection()
{
	InitialContext ic;
	Connection con=null;
	DataSource ds=null;
	try {
		ic = new InitialContext();
	ds=(DataSource) ic.lookup("java:/Jdbc/OracleDS");
	con=ds.getConnection();
	} catch (SQLException|NamingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return con;
}
}
